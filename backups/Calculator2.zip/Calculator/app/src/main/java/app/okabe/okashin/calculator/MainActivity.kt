package app.okabe.okashin.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import app.okabe.okashin.calculator.databinding.ActivityMainBinding
import java.math.RoundingMode
import java.math.BigDecimal

class MainActivity : AppCompatActivity() {


    /*
        連続計算に対応
        文字入力欄が2行にならないように
     */
    //TODO マイナスボタンをsecondNumberでも反応するようにする
    //TODO クリア(削除)ボタンぐらい作れるかも？？？
    //TODO 符号を表示したい

    // バインディングクラスの変数
    private lateinit var binding: ActivityMainBinding

    // 1番目に入力される変数を作る
    private var firstNumber: BigDecimal = BigDecimal.valueOf(0)
    // 2番目に入力される変数を作る
    private var secondNumber: BigDecimal = BigDecimal.valueOf(0)
    // 合計を入れる変数を作る
    private var totalNumber: BigDecimal = BigDecimal.valueOf(0)
    // 符号入力状態を待つ変数を、最初はempty(空)で作る
    private var operator: String = "empty"
    private var floatValue: Double = 1.0

    private val maxLength:Int = 8

    private val noContinueModes = listOf("empty", "negative", "dot")

    private fun roundNumber(number: BigDecimal): BigDecimal {
        // 123.456789 -> 小数点第5位四捨五入
        // 12.3456789 -> 小数点大6位四捨五入

        return number.stripTrailingZeros()
    }

    private fun inputNumber(number:Int) {
        // 符号ボタンと等号ボタンを利用できるようにする
        binding.plusButton.isEnabled = true
        binding.minusButton.isEnabled = true
        binding.multiplyButton.isEnabled = true
        binding.equalButton.isEnabled = true
        binding.divisionButton.isEnabled = true
        binding.dotButton.isEnabled = true
        binding.percentButton.isEnabled = true

        /*使われていない プラスマイナスボタンの処理・実装
        binding.plusMinusButton.setOnClickListener {
            if (binding.numberText.text == "0") {
                firstNumber = -0
                binding.numberText.text = "-0"
            }else if (binding.numberText.text == "-0") {
                firstNumber = 0
                binding.numberText.text = "0"
            } else {
                binding.plusMinusButton.isEnabled = false
            }
        }*/
        // 符号の入力状態を待つ変数が、emptyかどうか
        when (operator) {
            "empty" -> {
                // 一番目に入力された数を10倍してnumberを足す
                firstNumber = firstNumber*10.toBigDecimal() + number.toBigDecimal()
                firstNumber = roundNumber(firstNumber)
                // 数字を入力するTextViewに反映
                binding.numberText.text = firstNumber.toPlainString()
            }
            "negative" -> {
                // 一番目に入力された数を10倍してnumberを引く
                firstNumber = firstNumber*10.toBigDecimal() - number.toBigDecimal()
                firstNumber = roundNumber(firstNumber)
                // 数字を入力するTextViewに反映
                binding.numberText.text = firstNumber.toPlainString()
            }
            "dot" -> {
                firstNumber = (firstNumber.toDouble() + number.toDouble() / Math.pow(10.0, floatValue)).toBigDecimal()    //TODO ゴリ押s...
                firstNumber = roundNumber(firstNumber)
                binding.numberText.text = firstNumber.toPlainString()
                floatValue += 1.0
            }
            else -> {
                // 2番目に入力された数を10倍してnumberを足す
                secondNumber = secondNumber*10.toBigDecimal() + number.toBigDecimal()
                secondNumber = roundNumber(secondNumber)
                binding.numberText.text = secondNumber.toPlainString()
            }
        }
    }

    private fun calculation(){
        when (operator) {
            // 符号が+だったら
            "plus" -> {
                totalNumber = firstNumber + secondNumber
            }
            // 符号が-だったら
            "minus" -> {
                totalNumber = firstNumber - secondNumber
            }
            // 符号が*だったら
            "multiply" -> {
                totalNumber = firstNumber * secondNumber
            }
            // 符号が÷だったら
            "division" -> {
                totalNumber =
                    BigDecimal(firstNumber.toDouble() / secondNumber.toDouble())                //TODO ここが無理やりなのを直したい(あとこのままだと正確に計算できない)
//                totalNumber = firstNumber.divide(secondNumber)
                // 123.456789 -> 小数点第5位四捨五入
                // 12.3456789 -> 小数点大6位四捨五入
            }
        }
        totalNumber = roundNumber(totalNumber)
    }


    private fun continueCalc() {
        if (secondNumber == BigDecimal.valueOf(0)) {
            // 2番目に入力された文字をTextViewに反映させる
            binding.numberText.text = secondNumber.toPlainString()
        } else {
            calculation()
            firstNumber = totalNumber
            binding.numberText.text = firstNumber.toPlainString()
            secondNumber = 0.0.toBigDecimal()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater).apply { setContentView(this.root) }

        // 画面起動時は、符号ボタンと等号ボタンを利用できないようにする
        binding.plusButton.isEnabled = false
        binding.minusButton.isEnabled = false
        binding.multiplyButton.isEnabled = false
        binding.equalButton.isEnabled = false
        binding.divisionButton.isEnabled = false
        binding.dotButton.isEnabled = false
        binding.percentButton.isEnabled = false

        // 一番目に入力される変数を、TextViewに反映させる
        binding.numberText.text = firstNumber.toPlainString()


        // ボタン0が押されたら
        binding.numberButton0.setOnClickListener { inputNumber(0) }

        // ボタン1が押されたら
        binding.numberButton1.setOnClickListener { inputNumber(1) }

        // ボタン2が押されたら
        binding.numberButton2.setOnClickListener { inputNumber(2) }

        // ボタン3が押されたら
        binding.numberButton3.setOnClickListener { inputNumber(3) }
        // ボタン4が押されたら
        binding.numberButton4.setOnClickListener { inputNumber(4) }

        // ボタン5が押されたら
        binding.numberButton5.setOnClickListener { inputNumber(5) }
        // ボタン6が押されたら
        binding.numberButton6.setOnClickListener { inputNumber(6) }

        // ボタン7が押されたら
        binding.numberButton7.setOnClickListener { inputNumber(7) }

        // ボタン8が押されたら
        binding.numberButton8.setOnClickListener { inputNumber(8) }

        // ボタン9が押されたら
        binding.numberButton9.setOnClickListener { inputNumber(9)  }


        // +ボタンが押されたら
        binding.plusButton.setOnClickListener {
            continueCalc()
            // 符号を入れる前に、+を表す「plus」という文字を入れる
            operator = "plus"
        }


        // -ボタンが押されたら
        binding.minusButton.setOnClickListener {
            continueCalc()
            if (firstNumber == BigDecimal.valueOf(0)) {
                operator = "negative"
                secondNumber = BigDecimal.valueOf(0)
            } else {
                // 符号を入れる前に、-を表す「minus」という文字を入れる
                operator = "minus"
            }
        }

        // *ボタンが押されたら
        binding.multiplyButton.setOnClickListener {
            continueCalc()
            // 符号を入れる前に、*を表す「multiply」という文字を入れる
            operator = "multiply"
        }

        // %ボタンが押されたら
        binding.percentButton.setOnClickListener {
            continueCalc()
            firstNumber = (firstNumber.toDouble() / 100).toBigDecimal()  //TODO ここも無理やりだから直したい
            firstNumber = roundNumber(firstNumber)
            binding.numberText.text = firstNumber.toPlainString()
        }

        // ÷ボタンが押されたら
        binding.divisionButton.setOnClickListener {
            continueCalc()
            operator = "division"
        }

        // .ボタンが押されたら
        binding.dotButton.setOnClickListener {
            if (! binding.numberText.text.contains(".")) {
                operator = "dot"
                binding.numberText.text = firstNumber.toPlainString() + "."             //TODO secondNumberを小数にできない
            }
        }

        // √ボタンが押されたら
        binding.rootButton.setOnClickListener {
            firstNumber = Math.sqrt(firstNumber.toDouble()).toBigDecimal()
            firstNumber = roundNumber(firstNumber)
            binding.numberText.text = firstNumber.toPlainString()
        }

        // ^ボタンが押されたら
        binding.powButton.setOnClickListener {
            firstNumber = Math.pow(firstNumber.toDouble(), 2.0).toBigDecimal()
            firstNumber = roundNumber(firstNumber)
            binding.numberText.text = firstNumber.toPlainString()
        }

        // πボタンが押されたら
        binding.piButton.setOnClickListener {
            firstNumber = (firstNumber.toDouble() * Math.PI).toBigDecimal()
            firstNumber = roundNumber(firstNumber)
            binding.numberText.text = firstNumber.toPlainString()
        }

        // 税 ボタンが押されたら
        binding.taxButton.setOnClickListener {
            firstNumber *= 1.1.toBigDecimal()
            binding.numberText.text = firstNumber.toPlainString()
        }

        // =ボタンが押されたら
        binding.equalButton.setOnClickListener {
            calculation()

            // 1番目、2番目に入力される数字を入れる変数を0にセット
            firstNumber = BigDecimal.valueOf(0)
            secondNumber = BigDecimal.valueOf(0)
            // 符号の入力状態を待つ変数をemptyにセット
            operator = "empty"
            // 合計をTextViewに表示
            binding.numberText.text = totalNumber.toPlainString()
            totalNumber = BigDecimal.valueOf(0)
        }

        // Cボタンが押されたら
        binding.clearButton.setOnClickListener {
            if (secondNumber == BigDecimal(0)) {
                firstNumber = BigDecimal(0)
                binding.numberText.text = firstNumber.toPlainString()
            } else {
                secondNumber = BigDecimal(0)
                binding.numberText.text = secondNumber.toPlainString()
            }
        }

        // ACボタンが押されたら
        binding.allClearButton.setOnClickListener {
            // 1番目、2番目に入力される数字を入れる変数を0にセット
            firstNumber = BigDecimal.valueOf(0)
            secondNumber = BigDecimal.valueOf(0)
            // 合計を入れる変数を初期化
            totalNumber = BigDecimal.valueOf(0)
            // 符号の入力状態を待つ変数をemptyにセット
            operator = "empty"
            // TextViewを初期化
            binding.numberText.text = firstNumber.toPlainString()
        }
    }
}
